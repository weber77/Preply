//package fr.soro.batch;
//import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
//import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
//import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.context.annotation.Import;
//
//import fr.soro.batch.quartz.QuartzConfiguration;
//
//
///**
// * 
// * @author Soro
// */
//@Configuration
//@EnableBatchProcessing
//@Import({QuartzConfiguration.class})
//public class BatchConfiguration {
//
//	@Autowired
//	public JobBuilderFactory jobBuilderFactory;
//	@Autowired
//	public StepBuilderFactory stepBuilderFactory;
//	
//
//}
