# Les Etapes de deploiement de Projet 7 client 

## Prémière étape:
* Ce projet étant lier à d'autres nous avons fait un readme global pour simplifier l'explication 
  
 * Veuillez cliquer sur le lien ci-dessous pour y accéder.
  
  
[README GLOBAL](https://github.com/soro1987/projet-p7/blob/main/p7_bibliotheque-master/README.md) <br>

