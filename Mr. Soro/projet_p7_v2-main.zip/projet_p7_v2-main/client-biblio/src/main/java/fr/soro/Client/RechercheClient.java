package fr.soro.Client;
import org.springframework.stereotype.Service;
@Service
public class RechercheClient {

}
