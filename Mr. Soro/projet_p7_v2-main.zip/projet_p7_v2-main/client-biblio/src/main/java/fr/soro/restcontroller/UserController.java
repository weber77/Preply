package fr.soro.restcontroller;

public class UserController {

}
