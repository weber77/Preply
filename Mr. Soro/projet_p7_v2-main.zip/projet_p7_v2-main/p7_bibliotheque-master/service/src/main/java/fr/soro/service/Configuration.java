package fr.soro.service;
//package fr.soro.dtao;
//import org.springframework.context.annotation.ComponentScan;
//
//import org.springframework.context.annotation.Import;
//
//
//
//@org.springframework.context.annotation.Configuration
//@ComponentScan
//public class Configuration {
//
//}
