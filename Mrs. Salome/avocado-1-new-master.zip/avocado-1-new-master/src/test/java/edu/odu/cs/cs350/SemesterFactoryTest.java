/**
 * 
 */
package edu.odu.cs.cs350;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

/**
 * @author bwarren
 *
 */
public class SemesterFactoryTest {

	/**
	 * @throws java.lang.Exception
	 */
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
	}

	/**
	 * Test method for {@link edu.odu.cs.cs350.SemesterFactory#createSemester(java.lang.String)}.
	 */
	@Test
	public void testCreateSemester() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link edu.odu.cs.cs350.SemesterFactory#semesterDatesArePresent(java.lang.String, java.lang.String)}.
	 */
	@Test
	public void testSemesterDatesArePresent() {
		fail("Not yet implemented");
	}

}
