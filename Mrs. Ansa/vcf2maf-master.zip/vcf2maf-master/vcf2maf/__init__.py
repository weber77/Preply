from vcf2maf import list_samples, vcf2maf

__version__ = '0.0.1'
