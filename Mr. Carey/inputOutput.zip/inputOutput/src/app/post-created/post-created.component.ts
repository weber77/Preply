import { Component, OnInit , EventEmitter, Output} from '@angular/core';

export interface Post {
  title:string;
  content:string;
}

@Component({
  selector: 'app-post-created',
  templateUrl: './post-created.component.html',
  styleUrls: ['./post-created.component.css']
})
export class PostCreatedComponent implements OnInit {

  post:Post;
  @Output() postCreated = new EventEmitter<Post>();

  constructor() {
    this.post = {} as Post;
   }


  onAddPost()
  {
    const post = {
      title: this.post.title,
      content: this.post.content
    }

    this.postCreated.emit(post);
  }

  ngOnInit(): void {
  }

}
