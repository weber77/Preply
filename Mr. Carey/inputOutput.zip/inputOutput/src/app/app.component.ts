import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})


export class AppComponent {
  fruits = ['Mango', 'Orange', "Banana"];
  storedPosts = []

  addFruit(item){
    this.fruits.push(item);
  }

  onPostAdded(event){
    this.storedPosts.push(event);
  }

  title = 'inputOutput';
  constructor(){}
}
